<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Campos básicos
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $confirm_password = $conn->real_escape_string($_POST['confirm_password']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $birthdate = $conn->real_escape_string($_POST['birthdate']);
    
    // Nuevos campos médicos (con validación de existencia)
    $gender = isset($_POST['gender']) ? $conn->real_escape_string($_POST['gender']) : '';
    $address = isset($_POST['address']) ? $conn->real_escape_string($_POST['address']) : '';

    // Validación de contraseña
    if ($password !== $confirm_password) {
        echo "
        <script>
        Swal.fire({
            icon: 'error',
            title: '¡Oops!',
            text: 'Las contraseñas no coinciden. Por favor, verifica tus datos.',
            confirmButtonText: 'Volver'
        }).then(() => {
            history.back();
        });
        </script>";
        exit();
    }

    // Validación de email único
    $check_email_query = "SELECT id FROM usuario WHERE email = '$email'";
    $result = $conn->query($check_email_query);

    if ($result && $result->num_rows > 0) {
        echo "
        <script>
        Swal.fire({
            icon: 'warning',
            title: 'Correo ya registrado',
            text: 'El correo electrónico ingresado ya existe. Intenta con otro o inicia sesión.',
            confirmButtonText: 'Volver'
        }).then(() => {
            history.back();
        });
        </script>";
        exit();
    }

    // Hash de contraseña
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insertar en la BD con todos los campos
    $sql = "INSERT INTO usuario (
                nombre_completo, 
                email, 
                password, 
                tell, 
                fecha_nacimiento, 
                rol, 
                genero, 
                direccion,
                medical_history,
                fecha_registro
            ) VALUES (
                '$name', 
                '$email', 
                '$hashed_password', 
                '$telefono', 
                '$birthdate', 
                'paciente', 
                '$gender', 
                '$address',
                '',
                NOW()
            )";

    if ($conn->query($sql) === TRUE) {
        // Iniciar sesión automáticamente después del registro
        session_start();
        $_SESSION['id'] = $conn->insert_id;
        $_SESSION['email'] = $email;
        $_SESSION['rol'] = 'paciente';
        $_SESSION['nombre'] = $name;
        
        echo "
        <script>
        Swal.fire({
            icon: 'success',
            title: '¡Registro exitoso!',
            text: 'Bienvenido a Pro-Piel.',
            confirmButtonText: 'Ir al panel',
            allowOutsideClick: false
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'dashboard/dashboard.php';
            }
        });
        </script>";
    } else {
        echo "
        <script>
        Swal.fire({
            icon: 'error',
            title: 'Error al registrar',
            text: 'Error: " . addslashes($conn->error) . "',
            confirmButtonText: 'Volver'
        }).then(() => {
            history.back();
        });
        </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registro | Pro-Piel</title>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<!-- Este espacio vacío es necesario para que SweetAlert funcione -->
</body>
</html>