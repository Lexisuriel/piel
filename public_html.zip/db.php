<?php

class Database {
    private $servername = "localhost";
    private $username = "u493942604_derma_propiel";
    private $password = "Propiel2025";
    private $dbname = "u493942604_propiel";
    private $conn;

    // Constructor para establecer la conexión
    public function __construct() {
        $this->connect();
    }

    // Método privado para establecer la conexión
    private function connect() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        // Verificar conexión
        if ($this->conn->connect_error) {
            die("No se pudo conectar a la base de datos: " . $this->conn->connect_error);
        }
    }
    // Método para obtener la conexión
    public function getConnection() {
        return $this->conn;
    }   
}
// Uso de la clase
$db = new Database();
$conn = $db->getConnection();
?>
