<?php
session_start();

if (!isset($_SESSION['id'])) {
    header('Location: ../index.php');
    exit();
}

require_once("../db.php");

$nombre = $_SESSION['nombre_completo'];
$email = $_SESSION['email'];
$id_usuario = $_SESSION['id'];

$db = new Database();
$conn = $db->getConnection();

$sql = "SELECT tell, fecha_nacimiento FROM usuario WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $stmt->bind_result($telefono, $fecha_nacimiento);
    $stmt->fetch();
    $stmt->close();
}

$edad = "Desconocida";
if (!empty($fecha_nacimiento)) {
    $fecha_nac = new DateTime($fecha_nacimiento);
    $hoy = new DateTime();
    $edad = $hoy->diff($fecha_nac)->y;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard de Pacientes - Pro-Piel</title>
    <link rel="icon" href="../ico/logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fc;
        }

        .sidebar {
            width: 250px;
            background-color: #2a9d8f;
            color: #fff;
            padding: 20px;
            height: 100vh;
            position: fixed;
        }

        .sidebar h2 {
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: #fff;
            text-decoration: none;
            margin: 15px 0;
            font-weight: 500;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #21867a;
            padding-left: 10px;
            border-radius: 5px;
        }

        .dashboard-content {
            margin-left: 270px;
            padding: 40px;
            flex: 1;
        }

        .dashboard-header {
            background-color: #ffffff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .dashboard-header h1 {
            margin: 0;
            font-size: 28px;
            color: #2a9d8f;
        }

        .dashboard-header span {
            font-size: 14px;
            color: #888;
        }

        .dashboard-container .section {
            background-color: #ffffff;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .section h3 {
            color: #2a9d8f;
            margin-bottom: 15px;
        }

        .action-button {
            background-color: #2a9d8f;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }

        .action-button:hover {
            background-color: #21867a;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2><i class="fas fa-user-md"></i> Pro-Piel</h2>
        <a href="dashboard.php"><i class="fas fa-home"></i> Inicio</a>
        <a href="agendar_cita.php"><i class="fas fa-calendar-check"></i> Mis Citas</a>
        <a href="ver_consentimiento.php"><i class="fas fa-file-alt"></i> Consentimiento Informado</a>
        <a href="#historial"><i class="fas fa-notes-medical"></i> Historial</a>
        <a href="editarperfil.php"><i class="fas fa-user"></i> Perfil</a>
        <a href="#ayuda"><i class="fas fa-question-circle"></i> Ayuda</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
    </div>

    <div class="dashboard-content">
        <div class="dashboard-header">
            <h1>Bienvenido, <?php echo htmlspecialchars($nombre); ?></h1>
            <span>Panel de Paciente</span>
        </div>

        <div class="section" id="mis-citas">
    <h3>Próximas Citas</h3>
    <a href="ver_citas.php" class="btn btn-primary mb-3">
        <i class="fas fa-calendar-check"></i> Ver citas agendadas
    </a>
    <p>Aquí aparecerán tus próximas citas.</p>
</div>
            <div class="section" id="historial">
                <h3><i class="fas fa-file-medical-alt"></i> Historial de Tratamientos</h3>
                <p>Consulta tu historial médico aquí.</p>
            </div>

            <div class="section" id="perfil">
                <h3><i class="fas fa-user-circle"></i> Perfil</h3>
                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($nombre); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($telefono ?? "No registrado"); ?></p>
                <p><strong>Edad:</strong> <?php echo htmlspecialchars($edad); ?> años</p>
                <a href="editarperfil.php" class="action-button"><i class="fas fa-edit"></i> Editar Perfil</a>
            </div>
        </div>
    </div>
</body>
</html>
